/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package puzzle;
import java.awt.*;
import javax.swing.*;
/**
 *
 * @author shiva
 */


public class LoadingPage extends JFrame {
   private JProgressBar progressBar;

   public LoadingPage() {
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      setTitle("Slide Tiles Mind Challenge");
      setSize(600, 400);
      setResizable(false);
      setLocationRelativeTo(null);

      // Add background image
      setContentPane(new JLabel(new ImageIcon("S:\\8-puzzle\\8-puzzzle\\8-puzzle\\src\\puzzle\\new.jpg")));

      // Create panel for progress bar
      JPanel panel = new JPanel(new GridBagLayout());
      GridBagConstraints gbc = new GridBagConstraints();
      gbc.gridx = 0;
      gbc.gridy = 0;
      gbc.insets = new Insets(10, 10, 10, 10);
//      panel.add(new JLabel("Loading game..."), gbc);
      panel.setOpaque(false); // Make panel transparent
      add(panel);
      
      // Add progress bar to panel
      progressBar = new JProgressBar(0, 100);
      progressBar.setStringPainted(true);
      gbc.gridy++;
      panel.add(progressBar, gbc);
   }

   public void setProgress(int progress) {
      progressBar.setValue(progress);
   }

   public static void main(String[] args) {
      LoadingPage loadingPage = new LoadingPage();
      loadingPage.setVisible(true);

      // Simulate loading game
      for (int i = 0; i <= 100; i++) {
         try {
            Thread.sleep(50);
         } catch (InterruptedException e) {
            e.printStackTrace();
         }
         loadingPage.setProgress(i);
      }

      // Start game
      LoginPage loginpage=new LoginPage();
      loginpage.setVisible(true);
      loadingPage.setVisible(false);
   }
}

