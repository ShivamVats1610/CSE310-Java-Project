/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package puzzle;

import java.util.Arrays;
import java.util.Random;
/**
 *
 * @author shiva
 */
public class BoardControl {
    public static enum MOVES{UP, DOWN, RIGHT, LEFT};
    public static final byte[] GOAL = {1, 2, 3, 4, 5, 6, 7, 8, 0};
    private byte[] current = {1, 2, 3, 4, 5, 6, 7, 8, 0};
    private boolean solving = false;
    
    public boolean isSolving(){
        return this.solving;
    }
    
    public byte[] getCurrentBoard(){
        return current.clone();
    }
    
    public void setCurrentBoard(byte[] b){
        this.current = b;
    }

    public void tilePressed(int btn){
        int blank = getBlankIndex(current);
        if(btn == blank-1){
            move(current, MOVES.LEFT);
        }else if(btn == blank+1){
            move(current, MOVES.RIGHT);
        }else if(btn == blank+3){
            move(current, MOVES.DOWN);
        }else if(btn == blank-3){
            move(current, MOVES.UP);
        }
    }
    
    //make a move on the given board, changes the given board
    //if the move is invalid, do nothing
    //Note that the move is according to the blank, i.e. the blank moves UP or DOWN and so on
    public static void move(byte[] board, MOVES toMove){
        int blank = getBlankIndex(board);
        if(blank == -1) return;  //impossible, but just to be sure
        switch(toMove){
            case UP:
                if(blank/3 != 0) swap(board, blank, blank-3);
                break;
            case DOWN:
                if(blank/3 != 2) swap(board, blank, blank+3);
                break;
            case RIGHT:
                if(blank%3 != 2) swap(board, blank, blank+1);
                break;
            case LEFT:
                if(blank%3 != 0) swap(board, blank, blank-1);
                break;
        }
    }
    
    public boolean isSolved(){
        return Arrays.equals( this.GOAL, current);   
    }
    
    //resets the board
    public void resetBoard(){
        for(int i = 0 ; i < current.length-1 ; ++i) current[i] = (byte)(i+1);
        current[current.length - 1] = 0;
    }
    
    
    //generates a random, solvable board and makes it the current board
    public void randomizeBoard(){
        byte board[];
        while(!isSolvable(board = getRandomBoard()));
        current = board;
    }
    
    //makes a state at random, not necessarly solvable
    private byte[] getRandomBoard(){
        boolean f[] = new boolean[current.length];
        byte board[] = new byte[current.length];
        Random rand = new Random();
        
        //randomizes each element and make sure no element is repeated
        for(int i = 0 ; i < current.length ; ++i){
            byte t;
            while(f[t = (byte)rand.nextInt(9)]);
            f[t] = true;
            board[i] = t;
        }
        return board;
    }
    
    //checks if the given state is solvable or not
    private boolean isSolvable(byte board[]){
        //inversion counter
        int inv = 0;
        for(int i = 0 ; i < board.length ; ++i){
            if(board[i] == 0) continue;
            for(int j = i+1 ; j < board.length ; ++j){
                //wrong precedence, count an inversion
                if(board[j] != 0 && board[i] > board[j]) ++inv;
            }
            
        }
        
        //the board is solvable if the number of inversions is even
        return (inv % 2 == 0);
    }
    
    //returns the index of the blank element in the given board, -1 if not found (impossible case)
    public static int getBlankIndex(byte[] board){
        for(int i = 0 ; i < board.length ; ++i) if(board[i] == 0) return i;
        return -1;
    }
    
    public static void swap(byte[] board, int i, int j){
        try{
            byte iv = board[i];
            byte jv = board[j];
            board[i] = jv;
            board[j] = iv;
        }catch(ArrayIndexOutOfBoundsException ex){
        }
    }
}

