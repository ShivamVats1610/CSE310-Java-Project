/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package puzzle;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
/**
 *
 * @author shiva
 */




public class LoginPage extends JFrame implements ActionListener {
    private JLabel titleLabel, userLabel, passLabel;
    private JTextField userText;
    private JPasswordField passText;
    private JButton loginButton;
    private ImageIcon backgroundImage;

    public LoginPage() {
        // Set up the frame
        setTitle("Slide Tiles Mind Challenge");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        
        // Create the background image and set it as the content pane
        backgroundImage = new ImageIcon("S:\\8-puzzle\\8-puzzzle\\8-puzzle\\src\\puzzle\\log.jpg");
        setContentPane(new JLabel(backgroundImage));
        
        // Create the components for the login form
        titleLabel = new JLabel("Login");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(200, 50, 100, 50);

        userLabel = new JLabel("Username:");
        userLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        userLabel.setForeground(Color.white);
        userLabel.setBounds(100, 100, 80, 25);

        passLabel = new JLabel("Password:");
        passLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        passLabel.setForeground(Color.white);
        passLabel.setBounds(100, 150, 80, 25);

        userText = new JTextField();
        userText.setBounds(190, 100, 200, 25);

        passText = new JPasswordField();
        passText.setBounds(190, 150, 200, 25);

        loginButton = new JButton("Login");
        loginButton.setFont(new Font("Arial", Font.PLAIN, 14));
        loginButton.setBounds(200, 200, 100, 25);
        loginButton.addActionListener(this);
        
        // Add the components to the content pane
        add(titleLabel);
        add(userLabel);
        add(passLabel);
        add(userText);
        add(passText);
        add(loginButton);
        
        // Make the frame visible
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        // Handle login button click event
        if (e.getSource() == loginButton) {
            String username = userText.getText();
            String password = new String(passText.getPassword());
            
            // Authenticate the user (not implemented in this example)
            if (username.equals("admin") && password.equals("password")) {
//                JOptionPane.showMessageDialog(this, "Login successful!");
                GUI gui = new GUI();
                gui.setVisible(true);
                setVisible(false);
            } else {
                JOptionPane.showMessageDialog(this, "Incorrect username or password");
            }
        }
    }

}
