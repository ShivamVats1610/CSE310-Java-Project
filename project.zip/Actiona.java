/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package puzzle;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author shiva
 */
public class Actiona {
    public void  showprint(int  moveCount , int timeElapsed){
        
        JFrame frame = new JFrame();
        try {
      JOptionPane.showMessageDialog(null,
                    "Congratulations! You solved the puzzle in " + moveCount + " moves and " + timeElapsed + " Seconds ");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    } catch(Exception e) {
      // If an exception occurs, show a pop-up message with the error
      JOptionPane.showMessageDialog(frame, "Error setting default close operation: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
//                    JOptionPane.showMessageDialog(null,
//                    "Congratulations! You solved the puzzle in " + moveCount + " moves and " + timeElapsed + " Seconds ");
                    frame.setAlwaysOnTop(true);
                    frame.setVisible(true);
        
    }
}